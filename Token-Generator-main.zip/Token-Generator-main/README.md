<h1 align="center">Token Generator <img src="https://cdn3.emoji.gg/emojis/7277_green_flame.gif" width="30px"/> </h1>

[![Download](https://img.shields.io/badge/Download-Now-Green?style=for-the-badge)](https://github.com/LIONER-01/Token-Generator/archive/refs/heads/main.zip)
[![Stars](https://img.shields.io/github/stars/LIONER-01/Token-Generatorr?label=Stars&style=for-the-badge)](https://github.com/LIONER-01/Token-Generator/stargazers)

> If you like the project, consider dropping a star ⭐
  
> If you caught any issues, please report it in [issues](https://github.com/LIONER-01/Token-Generator/issues).

```
lunch the Gen.exe File 🍹<3
```
</h1>

|how to use |
|-------------------------------------------------|
Go to Token Generator\Config and edit Setting.txt
Open the Gen.exe file and enter the number you want Token to create
After creating the token and checking the token, the program saves the token in tokens.txt
I hope you like the program and get the final use 💖

</h1>



<p align="center">
  <img src="https://user-images.githubusercontent.com/114467257/213879811-825de125-988b-4839-8cc4-9bc311dc4d56.gif">
</p>

<details>
<summary>Preview</summary>
<img src="https://user-images.githubusercontent.com/114467257/213879893-d7591ee0-ab3f-4d58-8dcf-cc5d232f0453.PNG" alt="png">
</details>

---

### Features

* ` Easy To Use`
* ` Supports Windows, Linux and macOS`
* ` Fast Gen`

---

```javascript
if we hit 100 repo stars, i'll be adding some new features and UPDATES!
```
#### Credits
- [! lioner#1990](https://github.com/LIONER-01) (For Making the README)
