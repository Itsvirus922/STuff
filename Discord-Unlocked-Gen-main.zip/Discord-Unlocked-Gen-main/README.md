<div align="center">
  <kbd>
  <a href="https://github.com/imvast/Discord-Unlocked-Gen">
    <img src="https://cdn.discordapp.com/attachments/1099515953223569420/1100569773240229958/image.png" alt="Logo" style="width: 110%; height: 110%;">
  </a>
  </kbd>
  
  <h2 align="center">Discord - Unlocked Generator</h2>
  <p align="center">
    A simple and fast program to create discord accounts/tokens automatically (<b> created by me </b>)
    <br />
    <br />
    <a href="https://skiddos.t.me">💬 Telegram</a>
    ·
    <a href="https://github.com/imvast/Discord-Unlocked-Gen#-changelog">📜 ChangeLog</a>
    ·
    <a href="https://github.com/imvast/Discord-Unlocked-Gen/issues">⚠️ Report Bug</a>
    ·
    <a href="https://github.com/imvast/Discord-Unlocked-Gen/issues">💡 Request Feature</a>
  </p>
</div>

---

<h4>
publish date:
4/26/2023
may not work a couple days after release

if patched, you can purchase working version @ https://shop.saiv.cc
  
this version is working as of May 27th and if you want support join .gg/vast
</h4>

---

### ⚙️ Installation

- Requires: `Python 3.8+`
- Add your proxies to `proxies.txt`
- Edit the `config.toml` to your preference
- Start: `python3 main.py`

---

### 🔥 Features

- Slick UI
- Decent Speeds
- Simple & Easy To Setup
- UNLOCKED/UNFLAGGED ACCOUNTS
- Undetected Client
- Low Proxy Usage
- OPTION: Enable DEV Mode
- OPTION: Add BIO
- OPTION: Add PFP
- OPTION: Add Random Hypesquad
- OPTION: Join Server

---

### 🚀 Milestones

- NOT GIVING SUPPORT NOR CUSTOM UPDATES | PURCHASE @ https://shop.saiv.cc FOR LIFETIME UPDATES AND BETTER VERSION

---

### ❗ Disclaimers

- I am not responsible for anything that may happen, such as, API Blocking, Account Termination, etc.
- This **may** slow down your wifi and/or host computer
- This was a quick project that was made for fun, so if you want to see further updates, star the repo & create an "issue" [here](https://github.com/imvast/Discord-Unlocked-Gen/issues/new/choose)
- I made this in 1 hour so like i said along with the above, it was rushed and the code isn't the best

---

### 📜 ChangeLog

```diff
v0.0.1 ⋮ 04/09/2023
! Initial release
```

---

<p align="center">
  <img src="https://img.shields.io/github/license/imvast/Discord-Unlocked-Gen.svg?style=for-the-badge&labelColor=black&color=f429ff&logo=IOTA"/>
  <img src="https://img.shields.io/github/stars/imvast/Discord-Unlocked-Gen.svg?style=for-the-badge&labelColor=black&color=f429ff&logo=IOTA"/>
  <img src="https://img.shields.io/github/languages/top/imvast/Discord-Unlocked-Gen.svg?style=for-the-badge&labelColor=black&color=f429ff&logo=python"/>
</p>
